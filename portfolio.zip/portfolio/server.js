// server.js
const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to serve static files (e.g., your HTML, CSS, JS)
app.use(express.static('public'));

// Example data for projects
const projects = [
    {
        title: "Dances Of India (2023)",
        description: "A website which displays the dance forms in India using web programming.",
    },
    {
        title: "Public Transit Administration System (2024)",
        description: "A web-based interface for an owner to manage transport activities, using MySQL as front end and PHP as back end.",
    },
    {
        title: "Simulation of Living Room (2024)",
        description: "A project on a 3D view of a living room using computer graphics.",
    },
    {
        title: "Image Steganography (2024)",
        description: "An application where secret messages can be hidden in an image and decoded only with a secret key.",
    },
];

// Endpoint to get project data
app.get('/api/projects', (req, res) => {
    res.json(projects);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
